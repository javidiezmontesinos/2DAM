package hospitalApp;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class InsertarPacientes {
    public static void insertarPacientes() {
        try (SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
             Session session = sessionFactory.openSession()) {

      
            session.beginTransaction();
           Pacientes paciente = new Pacientes();
           paciente.setNombre("Paco");
           paciente.setApellidos("Lopez");
           paciente.setCiudad("Malaga");
           paciente.setDireccion("Urbanizacion Sauce");
           paciente.setTelefono("111111111");
           paciente.setEdad("30");
           paciente.setHistorial("Resfriado");
           session.save(paciente);
           session.getTransaction().commit();
           
        } catch (Exception e) {
           
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        
        insertarPacientes();
    }
}
