package hospitalApp;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class ModificarCitas {
    public static void modificarCitas() {
        try (SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
             Session session = sessionFactory.openSession()) {

            
            session.beginTransaction();
            String updateHql = "UPDATE Citas SET hora = '20:00' WHERE id = 1";
            Query<?> updateQuery = session.createQuery(updateHql);
            updateQuery.executeUpdate();
           session.getTransaction().commit();
           
        } catch (Exception e) {
           
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
       
    	modificarCitas();
    }
}
