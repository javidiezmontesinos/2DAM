package hospitalApp;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import hospitalApp.Citas;

import java.util.List;

public class MostrarPacientes{
    public static void visualizarPacientes() {
        try (SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
             Session session = sessionFactory.openSession()) {

           
            List<Pacientes> pacientesList = session.createQuery("from Pacientes", Pacientes.class).getResultList();

         
            System.out.println("Lista de citas:");
            for (Pacientes paciente : pacientesList) {
                System.out.println(paciente);
            }

        } catch (Exception e) {
          
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
      
        visualizarPacientes();
    }
}
