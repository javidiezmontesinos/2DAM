package hospitalApp;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class InsertarMedicos {
    public static void insertarMedicos() {
        try (SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
             Session session = sessionFactory.openSession()) {

      
            session.beginTransaction();
           Medicos medicos = new Medicos();
           medicos.setNombre("Juan");
           medicos.setApellidos("Lorenzo");
           session.save(medicos);
           session.getTransaction().commit();
           
        } catch (Exception e) {
           
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        
        insertarMedicos();
    }
}
