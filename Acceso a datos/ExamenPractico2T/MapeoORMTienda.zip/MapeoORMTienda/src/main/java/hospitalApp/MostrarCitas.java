package hospitalApp;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import hospitalApp.Citas;

import java.util.List;

public class MostrarCitas {
    public static void visualizarCitas() {
        try (SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
             Session session = sessionFactory.openSession()) {

           
            List<Citas> citasList = session.createQuery("from Citas", Citas.class).getResultList();

         
            System.out.println("Lista de citas:");
            for (Citas cita : citasList) {
                System.out.println(cita);
            }

        } catch (Exception e) {
          
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
      
        visualizarCitas();
    }
}
