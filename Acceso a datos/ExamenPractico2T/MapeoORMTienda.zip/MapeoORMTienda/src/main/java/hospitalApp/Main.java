package hospitalApp;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcionPrincipal = 0;

        do {
            System.out.println("------ Menú Principal ------");
            System.out.println("1. Gestionar pacientes");
            System.out.println("2. Gestionar medicos");
            System.out.println("3. Gestionar citas");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opcion: ");
            opcionPrincipal = scanner.nextInt();

            switch (opcionPrincipal) {
                case 1:
                    gestionarPacientes(scanner);
                    break;
                case 2:
                    gestionarMedicos(scanner);
                    break;
                case 3:
                    gestionarCitas(scanner);
                    break;
                case 4:
                    System.out.println("Cerrando...");
                    break;
                default:
                    System.out.println("Opcion incorrecta, introduce de nuevo");
                    break;
            }
        } while (opcionPrincipal != 4);

        scanner.close();
    }

    private static void gestionarPacientes(Scanner scanner) {
        int opcionPacientes = 0;

        do {
            System.out.println("------ Menu Pacientes ------");
            System.out.println("1. Insertar paciente");
            System.out.println("2. Actualizar paciente");
            System.out.println("3. Mostrar lista de pacientes");
            System.out.println("4. Eliminar paciente");
            System.out.println("5. Volver al menu principal");
            System.out.print("Seleccione una opcion: ");
            opcionPacientes = scanner.nextInt();

            switch (opcionPacientes) {
                case 1:
                    InsertarPacientes.insertarPacientes();
                    break;
                case 2:
                	ModificarPacientes.modificarPacientes();
                    break;
                case 3:
                    MostrarPacientes.visualizarPacientes();
                    break;
                case 4:
                    BorrarPacientes.eliminarPacientes();
                    break;
                case 5:
                    System.out.println("Volviendo al menu principal...");
                    break;
                default:
                    System.out.println("opcion incorrecta, introduce una opcion");
                    break;
            }
        } while (opcionPacientes != 5);
    }

    private static void gestionarMedicos(Scanner scanner) {
        int opcionMedicos = 0;

        do {
            System.out.println("------ Menu Medicos ------");
            System.out.println("1. Insertar medico");
            System.out.println("2. Actualizar medico");
            System.out.println("3. Mostrar lista de medicos");
            System.out.println("4. Eliminar medico");
            System.out.println("5. Volver al menu principal");
            System.out.print("Seleccione una opcion: ");
            opcionMedicos = scanner.nextInt();

            switch (opcionMedicos) {
                case 1:
                   InsertarMedicos.insertarMedicos();
                    break;
                case 2:
                   ModificarMedicos.modificarMedicos();
                    break;
                case 3:
                   MostrarMedicos.visualizarMedicos();
                    break;
                case 4:
                   BorrarMedicos.eliminarMedicos();
                    break;
                case 5:
                    System.out.println("Volviendo al menu principal...");
                    break;
                default:
                    System.out.println("opcion incorrecta, introduce una opcion");
                    break;
            }
        } while (opcionMedicos != 5);
    }

    private static void gestionarCitas(Scanner scanner) {
        int opcionCitas = 0;

        do {
            System.out.println("------ Menu Citas ------");
            System.out.println("1. Insertar cita");
            System.out.println("2. Actualizar cita");
            System.out.println("3. Mostrar lista de citas");
            System.out.println("4. Eliminar cita");
            System.out.println("5. Volver al menu principal");
            System.out.print("Seleccione una opcion: ");
            opcionCitas = scanner.nextInt();

            switch (opcionCitas) {
                case 1:
                    InsertarCitas.insertarCitas();
                    break;
                case 2:
                    ModificarCitas.modificarCitas();
                    break;
                case 3:
                    MostrarCitas.visualizarCitas();
                    break;
                case 4:
                	BorrarCitas.eliminarCitas();
                    break;
                case 5:
                    System.out.println("Volviendo al menu principal...");
                    break;
                default:
                    System.out.println("Opción no válida, por favor seleccione una opción válida.");
                    break;
            }
        } while (opcionCitas != 5);
    }
}
