package hospitalApp;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class BorrarPacientes {
    public static void eliminarPacientes() {
        try (SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
             Session session = sessionFactory.openSession()) {

            
            session.beginTransaction();
            String deleteHql = "DELETE FROM Pacientes WHERE id = 1";
            Query<?> deleteQuery = session.createQuery(deleteHql);
            deleteQuery.executeUpdate();
           session.getTransaction().commit();
           
        } catch (Exception e) {
          
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        // Ejemplo de uso
        eliminarPacientes();
    }
}
