package hospitalApp;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class MostrarMedicos {
    public static void visualizarMedicos() {
        try (SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
             Session session = sessionFactory.openSession()) {

            List<Medicos> medicosList = session.createQuery("from Medicos", Medicos.class).getResultList();

            System.out.println("Lista de médicos:");
            for (Medicos medico : medicosList) {
                System.out.println(medico);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        visualizarMedicos();
    }
}
