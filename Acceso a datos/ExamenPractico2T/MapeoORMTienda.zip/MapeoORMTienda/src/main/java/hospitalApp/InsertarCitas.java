package hospitalApp;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import hospitalApp.Citas;
import hospitalApp.Medicos;
import hospitalApp.Pacientes;

public class InsertarCitas {
    public static void insertarCitas() {
        try (SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
             Session session = sessionFactory.openSession()) {

            
            Pacientes paciente = session.get(Pacientes.class, 2); 
            Medicos medico = session.get(Medicos.class, 3); 
            
          
            Citas cita = new Citas(); 
            cita.setFecha("10/10/2052");
            cita.setHora("20:00");
          
            session.beginTransaction();
            session.save(cita);
            session.getTransaction().commit();
            
        } catch (Exception e) {
            
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        
        insertarCitas();
    }
}
