package simulacroAD2TA;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
    public static void main(String[] args) {
        Configuration configuration = new Configuration().configure();
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        // Crear un nuevo profesor
        Profesores nuevoProfesor = new Profesores();
        nuevoProfesor.setNombre("Juan");
        nuevoProfesor.setApellidos("Gómez");
        nuevoProfesor.setDireccion("Calle Principal");
        nuevoProfesor.setCp("12345");
        nuevoProfesor.setCiudad("Ciudad Real");
        nuevoProfesor.setProvincia("Ciudad Real");
        nuevoProfesor.setTelefono("123456789");

        // Guardar el profesor en la base de datos
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            session.save(nuevoProfesor);
            transaction.commit();
        }

        // Mostrar los profesores
        try (Session session = sessionFactory.openSession()) {
            session.beginTransaction();
            List<Profesores> profesores = session.createQuery("FROM Profesores", Profesores.class).list();
            for (Profesores profesor : profesores) {
                System.out.println(profesor);
            }
            session.getTransaction().commit();
        }

        sessionFactory.close();
    }
}
