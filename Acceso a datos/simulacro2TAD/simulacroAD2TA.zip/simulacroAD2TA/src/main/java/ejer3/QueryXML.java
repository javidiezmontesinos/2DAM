package ejer3;

import org.xmldb.api.DatabaseManager;
import org.xmldb.api.base.*;
import org.xmldb.api.modules.*;
import org.exist.xmldb.EXistResource;

import javax.xml.transform.OutputKeys;

public class QueryXML {

    // URI para conectarse a la base de datos XML existente en localhost en el
    // puerto 8080
    private static String URI = "xmldb:exist://localhost:8080/exist/xmlrpc/db/";

    // Nombre de la colección donde se encuentran los datos XML
    private static String COLLECTION = "series";

    // Nombre del recurso XML dentro de la colección
    private static String RESOURCE = "series.xml";

    public static void main(String args[]) throws Exception {

        final String driver = "org.exist.xmldb.DatabaseImpl";

        // Inicializa el controlador de la base de datos
        Class<?> cl = Class.forName(driver);
        Database database = (Database) cl.newInstance();
        database.setProperty("create-database", "true");
        DatabaseManager.registerDatabase(database);

        org.xmldb.api.base.Collection col = null;
        XMLResource res = null;
        try {
            // Obtiene la colección
            col = DatabaseManager.getCollection(URI + COLLECTION, "admin", "");

            // Configura la propiedad de salida para indentación
            col.setProperty(OutputKeys.INDENT, "yes");

            // Obtiene el recurso XML de la colección
            res = (XMLResource) col.getResource(RESOURCE);

            // Verifica si el recurso existe
            if (res == null) {
                System.out.println("Base de datos no encontrada!");
            } else {
                // Ejecutar consulta que muestra todos los datos
                System.out.println("Consulta 1: Todos los datos\n");
                System.out.println(res.getContent());

                // Ejecutar consulta que muestra solo las series cuya fecha de emisión inicial
                // es posterior o igual al año 2000
                System.out.println("\nConsulta 2: Series cuya fecha de emisión inicial es posterior o igual al año 2000\n");
                XPathQueryService xpathService = (XPathQueryService) col.getService("XPathQueryService", "1.0");
                xpathService.setProperty("indent", "yes");
                String xquery = "//serie[inicio_emision >= 2000]"; // Consulta para seleccionar las series con fecha de emisión inicial posterior o igual al año 2000
                ResourceSet result = xpathService.query(xquery);

                // Imprimir los resultados de la consulta
                ResourceIterator i = result.getIterator();
                while (i.hasMoreResources()) {
                    Resource r = i.nextResource();
                    System.out.println(r.getContent());
                }
            }
        } finally {
            // Limpieza de recursos

            if (res != null) {
                try {
                    // Liberar los recursos del recurso exist
                    ((EXistResource) res).freeResources();
                } catch (XMLDBException xe) {
                    xe.printStackTrace();
                }
            }

            if (col != null) {
                try {
                    // Cerrar la colección
                    col.close();
                } catch (XMLDBException xe) {
                    xe.printStackTrace();
                }
            }
        }
    }
}
